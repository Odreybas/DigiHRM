# DigiHRM

**A platform for people, skills, products and opportunities.**

DigiHRM is being developed as a discovery and professional showcase platform connecting people, businesses, products, services and jobs.

## Current starter scope
- Django REST Framework API with JWT authentication
- Custom user model and public/private profile visibility
- Business, product, service and post listings
- Job listings and applications
- Reviews with one target per review and duplicate-review constraints
- React + Vite starter interface
- GitHub Actions workflow for backend checks

## Technology
- Python / Django / Django REST Framework
- SQLite for local development
- React / Vite
- GitHub Actions

## Project status
This repository is an MVP foundation under active development. The current implementation is not production-ready. Messaging, real media uploads, geospatial search, verified transactions, moderation workflows, notification delivery, production deployment configuration and comprehensive end-to-end tests remain to be built.

## Local development
See `backend/README.md` and `frontend/README.md` for setup instructions.
