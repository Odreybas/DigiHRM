from django.contrib.auth import get_user_model
from rest_framework import serializers
from .models import Profile, Business, Product, Service, Post, Job, JobApplication, Review

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    class Meta:
        model = User
        fields = ("id", "username", "email", "password", "first_name", "last_name")
    def create(self, validated_data):
        password = validated_data.pop("password")
        user = User(**validated_data)
        user.set_password(password)
        user.save()
        Profile.objects.get_or_create(user=user)
        return user

class ProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source="user.username", read_only=True)
    class Meta:
        model = Profile
        fields = ("id", "user", "username", "bio", "location", "skills", "is_public")
        read_only_fields = ("user",)

class BusinessSerializer(serializers.ModelSerializer):
    class Meta:
        model = Business
        fields = "__all__"
        read_only_fields = ("owner",)

class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = "__all__"
        read_only_fields = ("owner",)

class ServiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Service
        fields = "__all__"
        read_only_fields = ("owner",)

class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = "__all__"
        read_only_fields = ("author",)

class JobSerializer(serializers.ModelSerializer):
    class Meta:
        model = Job
        fields = "__all__"
        read_only_fields = ("employer",)

class JobApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = JobApplication
        fields = ("id", "job", "applicant", "cover_note", "status", "created_at")
        read_only_fields = ("applicant", "status", "created_at")
    def validate_job(self, job):
        request = self.context.get("request")
        if request and job.employer_id == request.user.id:
            raise serializers.ValidationError("You cannot apply for your own job.")
        if not job.is_active:
            raise serializers.ValidationError("This job is no longer accepting applications.")
        return job

class ReviewSerializer(serializers.ModelSerializer):
    class Meta:
        model = Review
        fields = "__all__"
        read_only_fields = ("reviewer", "created_at")
    def validate(self, attrs):
        targets = [attrs.get("business"), attrs.get("product"), attrs.get("service")]
        if sum(target is not None for target in targets) != 1:
            raise serializers.ValidationError("A review must target exactly one business, product or service.")
        request = self.context.get("request")
        if request and request.user.is_authenticated:
            target = next(target for target in targets if target is not None)
            if getattr(target, "owner_id", None) == request.user.id:
                raise serializers.ValidationError("You cannot review your own listing.")
        return attrs
