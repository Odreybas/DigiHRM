from rest_framework.routers import DefaultRouter
from django.urls import path, include
from .views import (RegisterView, ProfileViewSet, BusinessViewSet, ProductViewSet,
    ServiceViewSet, PostViewSet, JobViewSet, JobApplicationViewSet, ReviewViewSet)

router = DefaultRouter()
router.register("profiles", ProfileViewSet)
router.register("businesses", BusinessViewSet)
router.register("products", ProductViewSet)
router.register("services", ServiceViewSet)
router.register("posts", PostViewSet)
router.register("jobs", JobViewSet)
router.register("applications", JobApplicationViewSet, basename="application")
router.register("reviews", ReviewViewSet)
urlpatterns = [path("auth/register/", RegisterView.as_view()), path("", include(router.urls))]
