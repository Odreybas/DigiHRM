from rest_framework.permissions import BasePermission, SAFE_METHODS

class IsOwnerOrReadOnly(BasePermission):
    """Allow public reads, but restrict mutations to the object's owner."""
    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        owner = getattr(obj, "owner", None)
        if owner is None:
            owner = getattr(obj, "author", None)
        if owner is None:
            owner = getattr(obj, "user", None)
        if owner is None:
            owner = getattr(obj, "employer", None)
        return owner == request.user
