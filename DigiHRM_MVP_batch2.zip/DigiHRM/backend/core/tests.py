from django.test import TestCase
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from .models import Profile, Business

User = get_user_model()

class RegistrationTests(TestCase):
    def test_register_creates_user_and_profile(self):
        response = APIClient().post("/api/auth/register/", {
            "username": "tester",
            "email": "test@example.com",
            "password": "StrongPass123!"
        }, format="json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(User.objects.filter(username="tester").exists())
        self.assertTrue(Profile.objects.filter(user__username="tester").exists())

class ProfilePermissionTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(username="owner", password="StrongPass123!")
        self.other = User.objects.create_user(username="other", password="StrongPass123!")
        self.profile = Profile.objects.create(user=self.owner, bio="Original")

    def test_other_user_cannot_edit_profile(self):
        client = APIClient()
        client.force_authenticate(self.other)
        response = client.patch(f"/api/profiles/{self.profile.id}/", {"bio": "Changed"}, format="json")
        self.assertEqual(response.status_code, 403)

    def test_owner_can_edit_profile(self):
        client = APIClient()
        client.force_authenticate(self.owner)
        response = client.patch(f"/api/profiles/{self.profile.id}/", {"bio": "Updated"}, format="json")
        self.assertEqual(response.status_code, 200)
        self.profile.refresh_from_db()
        self.assertEqual(self.profile.bio, "Updated")

class ReviewAccessTests(TestCase):
    def test_anonymous_user_cannot_create_review(self):
        business = Business.objects.create(owner=User.objects.create_user(username="seller"), name="Test business")
        response = APIClient().post("/api/reviews/", {
            "business": business.id, "rating": 5, "comment": "Good"
        }, format="json")
        self.assertEqual(response.status_code, 401)
