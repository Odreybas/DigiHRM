from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Profile, Business, Product, Service, Post, Job, JobApplication, Review
admin.site.register(User, UserAdmin)
for model in [Profile, Business, Product, Service, Post, Job, JobApplication, Review]:
    admin.site.register(model)
