from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class User(AbstractUser):
    email = models.EmailField(unique=True)

class Profile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="profile")
    bio = models.TextField(blank=True)
    location = models.CharField(max_length=160, blank=True)
    skills = models.JSONField(default=list, blank=True)
    is_public = models.BooleanField(default=True)
    def __str__(self): return self.user.username

class Business(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="businesses")
    name = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=100, blank=True)
    location = models.CharField(max_length=160, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self): return self.name

class Product(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="products")
    name = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    price = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    location = models.CharField(max_length=160, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Service(models.Model):
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="services")
    name = models.CharField(max_length=180)
    description = models.TextField(blank=True)
    category = models.CharField(max_length=100, blank=True)
    location = models.CharField(max_length=160, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Post(models.Model):
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="posts")
    title = models.CharField(max_length=180, blank=True)
    body = models.TextField()
    media_url = models.URLField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class Job(models.Model):
    employer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="jobs")
    title = models.CharField(max_length=180)
    description = models.TextField()
    location = models.CharField(max_length=160, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

class JobApplication(models.Model):
    STATUS = [(x, x.title()) for x in ("submitted", "reviewing", "shortlisted", "rejected", "accepted")]
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="applications")
    applicant = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="applications")
    cover_note = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS, default="submitted")
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta: constraints = [models.UniqueConstraint(fields=["job", "applicant"], name="unique_job_application")]

class Review(models.Model):
    reviewer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="reviews_written")
    business = models.ForeignKey(Business, null=True, blank=True, on_delete=models.CASCADE, related_name="reviews")
    product = models.ForeignKey(Product, null=True, blank=True, on_delete=models.CASCADE, related_name="reviews")
    service = models.ForeignKey(Service, null=True, blank=True, on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [
            models.CheckConstraint(condition=(models.Q(business__isnull=False, product__isnull=True, service__isnull=True) | models.Q(business__isnull=True, product__isnull=False, service__isnull=True) | models.Q(business__isnull=True, product__isnull=True, service__isnull=False)), name="review_exactly_one_target"),
            models.UniqueConstraint(fields=["reviewer", "business"], condition=models.Q(business__isnull=False), name="unique_business_review"),
            models.UniqueConstraint(fields=["reviewer", "product"], condition=models.Q(product__isnull=False), name="unique_product_review"),
            models.UniqueConstraint(fields=["reviewer", "service"], condition=models.Q(service__isnull=False), name="unique_service_review"),
        ]
