from rest_framework import generics, permissions, viewsets, filters
from django.contrib.auth import get_user_model
from .models import Profile, Business, Product, Service, Post, Job, JobApplication, Review
from .serializers import (RegisterSerializer, ProfileSerializer, BusinessSerializer,
    ProductSerializer, ServiceSerializer, PostSerializer, JobSerializer,
    JobApplicationSerializer, ReviewSerializer)
from .permissions import IsOwnerOrReadOnly

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = RegisterSerializer
    permission_classes = [permissions.AllowAny]

class OwnedViewSet(viewsets.ModelViewSet):
    permission_classes = [IsOwnerOrReadOnly]
    def perform_create(self, serializer):
        field = getattr(self, "owner_field", "owner")
        serializer.save(**{field: self.request.user})

class ProfileViewSet(viewsets.ModelViewSet):
    serializer_class = ProfileSerializer
    queryset = Profile.objects.filter(is_public=True)
    permission_classes = [IsOwnerOrReadOnly]
    http_method_names = ["get", "put", "patch", "head", "options"]
    def get_queryset(self):
        qs = Profile.objects.all()
        if self.request.user.is_authenticated:
            return qs.filter(is_public=True) | qs.filter(user=self.request.user)
        return qs.filter(is_public=True)
    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class BusinessViewSet(OwnedViewSet):
    serializer_class = BusinessSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["name", "description", "category", "location"]
    def get_queryset(self):
        qs = Business.objects.all()
        if self.request.user.is_authenticated:
            return qs.filter(is_active=True) | qs.filter(owner=self.request.user)
        return qs.filter(is_active=True)

class ProductViewSet(OwnedViewSet):
    serializer_class = ProductSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["name", "description", "location"]
    def get_queryset(self):
        qs = Product.objects.all()
        if self.request.user.is_authenticated:
            return qs.filter(is_active=True) | qs.filter(owner=self.request.user)
        return qs.filter(is_active=True)

class ServiceViewSet(OwnedViewSet):
    serializer_class = ServiceSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["name", "description", "category", "location"]
    def get_queryset(self):
        qs = Service.objects.all()
        if self.request.user.is_authenticated:
            return qs.filter(is_active=True) | qs.filter(owner=self.request.user)
        return qs.filter(is_active=True)

class PostViewSet(OwnedViewSet):
    queryset = Post.objects.filter(is_active=True)
    serializer_class = PostSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["title", "body"]
    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

class JobViewSet(OwnedViewSet):
    serializer_class = JobSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ["title", "description", "location"]
    def get_queryset(self):
        qs = Job.objects.all()
        if self.request.user.is_authenticated:
            return qs.filter(is_active=True) | qs.filter(employer=self.request.user)
        return qs.filter(is_active=True)
    def perform_create(self, serializer):
        serializer.save(employer=self.request.user)

class JobApplicationViewSet(viewsets.ModelViewSet):
    serializer_class = JobApplicationSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ['get', 'post', 'head', 'options']
    def get_queryset(self):
        return JobApplication.objects.filter(applicant=self.request.user) | JobApplication.objects.filter(job__employer=self.request.user)
    def perform_create(self, serializer):
        serializer.save(applicant=self.request.user)

class ReviewViewSet(viewsets.ModelViewSet):
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
    permission_classes = [permissions.IsAuthenticated]
    http_method_names = ['get', 'post', 'head', 'options']
    def perform_create(self, serializer):
        serializer.save(reviewer=self.request.user)
