# DigiHRM backend

## Requirements
Python 3.10+ is recommended.

## Local setup
```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Database setup
The project uses a custom user model. Generate and apply its initial migrations before creating users:
```bash
python manage.py check
python manage.py makemigrations core
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

API base: http://127.0.0.1:8000/api/

## Tests
```bash
python manage.py test
```

SQLite is configured for local development. Configure PostgreSQL and production security settings before deployment.
