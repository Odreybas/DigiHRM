import { useEffect, useState } from 'react'
import { Link, Routes, Route } from 'react-router-dom'
import api from './api'

function Home() {
  const [posts, setPosts] = useState([])
  const [error, setError] = useState('')
  useEffect(() => { api.get('/posts/').then(r => setPosts(r.data.results || r.data)).catch(() => setError('Connect the Django backend to load the feed.')) }, [])
  return <main><section className="hero"><p className="eyebrow">PEOPLE · SKILLS · OPPORTUNITIES</p><h1>Make your skills visible.</h1><p>Discover professionals, products, services and opportunities in one place.</p><Link className="primary" to="/explore">Explore DigiHRM</Link></section><section><h2>Community feed</h2>{error && <p className="muted">{error}</p>}{posts.map(post => <article className="panel" key={post.id}><h3>{post.title || 'Community update'}</h3><p>{post.body}</p></article>)}</section></main>
}
function Explore() { return <main><h1>Explore</h1><p>Discover people, businesses, products and services.</p><div className="tiles">{['People','Businesses','Products','Services','Jobs'].map(x=><div className="panel" key={x}><h3>{x}</h3><p>Browse {x.toLowerCase()} on DigiHRM.</p></div>)}</div></main> }
export default function App() { return <><header><Link to="/" className="brand">DigiHRM</Link><nav><Link to="/">Home</Link><Link to="/explore">Explore</Link></nav></header><Routes><Route path="/" element={<Home/>}/><Route path="/explore" element={<Explore/>}/></Routes><footer>DigiHRM · Discover what people can do.</footer></> }
