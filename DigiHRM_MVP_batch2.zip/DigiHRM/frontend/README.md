# DigiHRM frontend
```bash
npm install
npm run dev
```
Set `VITE_API_URL` in `.env` to your backend API base URL.
